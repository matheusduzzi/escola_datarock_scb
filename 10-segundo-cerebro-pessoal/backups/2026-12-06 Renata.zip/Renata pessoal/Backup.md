---
tipo: rotina
---
# Backup

## Como eu faço

1. No primeiro domingo do mês, compacto as duas pastas juntas, Renata pessoal e Renata privado, num zip com a data no nome: `2026-12-06 Renata.zip`.
2. Copio o zip para o HD externo, na pasta Backups. O zip tem o privado, então ele não vai para o iCloud, nem para e-mail, nem para pendrive emprestado.
3. Fico com os três últimos zips e apago o mais velho.

## Como eu testo, toda vez

1. Descompacto o zip numa pasta nova, `Restaurado`, fora dos cofres.
2. Vejo se os dois cofres estão lá e se o número de arquivos de cada um bate com o original.
3. Abro a pasta restaurada como cofre e abro três notas: a última do diário, a última nota de aula e a nota da viagem com quanto falta.
4. Anoto aqui o resultado, com a data.
5. Apago a pasta `Restaurado`, que é mais uma cópia do privado.

## Testes

- 30/11: o zip só tinha o Renata pessoal, com 15 arquivos. O Renata privado não estava lá: o diário, as contas e a saúde não tinham cópia nenhuma. Falhou. Eu tinha copiado a pasta do iCloud Drive achando que estava tudo lá. Mudei o passo 1 para levar as duas pastas.
