---
origem: nota rápida no celular
capturado: 2026-12-04
---
# Nota rápida: livro do clube

O livro do clube de dezembro chegou. Começar na segunda. Encontro dia 19/12.
