---
tipo: área
frente: leituras
---
# Leituras

O que eu quero: um livro por mês, e anotar nas minhas palavras o que eu vou usar.

Lendo: [[Leitura - livro de finanças da família]]

Lidos em 2026: três, anotados no caderno antes do cofre.

Na revisão de domingo: em que página estou, e se o resumo do último livro já tem o que eu vou usar.
