---
tipo: meta
---
# Viagem - quanto falta

Meta: R$ 8.400 guardados até 30/04/2027. O plano está no Renata pessoal, na nota Viagem de junho.

| Data | Entrou | Guardado |
|---|---|---|
| 29/11 | R$ 2.400 (o que eu já tinha) | R$ 2.400 |
| 05/12 | R$ 750 (novembro) | R$ 3.150 |

Falta: R$ 5.250
