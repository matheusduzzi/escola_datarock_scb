---
tipo: rotina
---
# Backup

## Como eu faço

No primeiro domingo do mês, compacto a pasta Renata pessoal do iCloud Drive num zip com a data no nome e copio para o HD externo, na pasta Backups.
